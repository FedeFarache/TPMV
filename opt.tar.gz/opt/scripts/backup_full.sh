#!/bin/bash

#Función para mostrar ayuda
mostrar_ayuda() {
    echo ""
    echo "╔════════════════════════════════════════════╗"
    echo "║        Script de Backup - backup_full.sh   ║"
    echo "╚════════════════════════════════════════════╝"
    echo ""
    echo "Uso:"
    echo "  $0 <origen> <destino>"
    echo ""
    echo "Parámetros:"
    echo "  <origen>   Directorio que se desea respaldar. Ej: /var/log"
    echo "  <destino>  Directorio de destino montado. Ej: /backup_dir"
    echo ""
    echo "Opciones:"
    echo "  -help      Muestra esta ayuda detallada."
    echo ""
    echo "Ejemplo de uso:"
    echo "  $0 /var/log /backup_dir"
    echo ""
    echo "Requisitos:"
    echo "  - El directorio origen debe existir."
    echo "  - El directorio destino debe estar montado (mountpoint válido)."
    echo ""
    echo "Resultado:"
    echo "  Se genera un archivo .tar.gz con la fecha actual en el nombre,"
    echo "  por ejemplo: log_bkp_20250608.tar.gz"
    echo ""
    exit 0
}

#Función para validar parámetros
validar_parametros() {
    if [ $# -ne 2 ]; then
        echo "Error: Se requieren exactamente 2 parámetros: origen y destino."
        echo "Ejecute '$0 -help' para ver la ayuda."
        exit 1
    fi
}

#Función para validar existencia de origen y destino
validar_directorios() {
    if [ ! -d "$1" ]; then
        echo "Error: El directorio de origen '$1' no existe."
        exit 1
    fi

    if ! mountpoint -q "$2"; then
        echo "Error: El destino '$2' no está montado o no es un punto de montaje válido."
        exit 1
    fi
}

#Función principal de backup
ejecutar_backup() {
    local ORIGEN="$1"
    local DESTINO="$2"
    local FECHA=$(date +%Y%m%d)
    local NOMBRE_ARCHIVO="$(basename "$ORIGEN")bkp${FECHA}.tar.gz"

    tar -czf "$DESTINO/$NOMBRE_ARCHIVO" "$ORIGEN"

    if [ $? -eq 0 ]; then
        echo "Backup creado exitosamente: $DESTINO/$NOMBRE_ARCHIVO"
    else
        echo "Error al generar el backup."
        exit 1
    fi
}

#--- Ejecución del script ---
#Mostrar ayuda si se pide
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
    mostrar_ayuda
fi

validar_parametros "$@"
validar_directorios "$1" "$2"
ejecutar_backup "$1" "$2"

